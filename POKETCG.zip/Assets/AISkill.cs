﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AISkill : MonoBehaviour
{
    public CardInfo[] cards= new CardInfo[6];

}
